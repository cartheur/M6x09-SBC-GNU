All disk images EXCEPT Swtpboot.dsk run on real hardware but won't
boot in the emulator.

Disk image Swtpboot.dsk boots in the emulator but won't run on
real hardware. It attempts to seek past track 40 during boot.